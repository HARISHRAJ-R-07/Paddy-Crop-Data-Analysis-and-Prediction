# 🌾 Paddy Crop Data Analysis and Prediction

**A Data Science mini project by Harishraj R**

[![Python](https://img.shields.io/badge/Python-3.x-blue?logo=python&logoColor=white)](https://www.python.org/)
[![Pandas](https://img.shields.io/badge/Data-Pandas-150458?logo=pandas&logoColor=white)](https://pandas.pydata.org/)
[![Scikit-learn](https://img.shields.io/badge/ML-Scikit--learn-F7931E?logo=scikitlearn&logoColor=white)](https://scikit-learn.org/)

## 📌 Project Overview

This project explores paddy cultivation data and builds supervised machine-learning regression models to estimate **paddy yield (in kg)** using cultivation-related features.

## 🎯 Objectives

- Understand the dataset through exploratory data analysis (EDA).
- Examine missing values, duplicate records, distributions, and relationships between variables.
- Prepare categorical features using one-hot encoding and scale numerical features.
- Select features and split data into training and testing sets.
- Train and compare regression models using cross-validation and hyperparameter tuning.
- Evaluate predictions with MAE, RMSE, and R².

## 📊 Dataset

- **Target:** `Paddy yield(in Kg)`
- **Source:** [Paddy dataset CSV on GitHub](https://raw.githubusercontent.com/HARISHRAJ-R-07/Project-dataset-csv-files/refs/heads/main/paddydataset.csv)
- The notebook downloads the CSV from the URL above, so an internet connection is required when running it.

## 🧰 Tools and Libraries

Python, NumPy, Pandas, Matplotlib, Seaborn, SciPy, and Scikit-learn.

## 🔎 Workflow

1. Load the dataset
2. Perform EDA and create visualizations
3. Handle duplicate records and inspect missing values
4. Encode categorical features and scale numerical features
5. Select features and split the data
6. Train regression models and tune hyperparameters with 5-fold cross-validation
7. Compare model performance using MAE, RMSE, and R²

## 🤖 Models

- Decision Tree Regressor
- Random Forest Regressor
- Gradient Boosting Regressor

## 📏 Evaluation Metrics

- **MAE:** Mean Absolute Error
- **RMSE:** Root Mean Squared Error
- **R² Score:** Coefficient of determination

Refer to the notebook's model evaluation section for the results produced by the notebook. Results can vary if the data or code changes.

## 🖼️ Visualizations

The `Visualizations/` folder contains plots exported from the notebook, including target distribution, outlier inspection, production comparisons, cultivated area versus production, temperature-stage analysis, and correlation heatmaps.

## 📁 Project Structure

```text
Paddy_Crop_Data_Analysis_and_Prediction/
├── Project_Notebook.ipynb
├── requirements.txt
├── README.md
└── Visualizations/
    ├── correlation_heatmap.png
    ├── target_distribution.png
    ├── target_outliers_boxplot.png
    ├── production_by_agricultural_block.png
    ├── production_by_paddy_variety.png
    ├── cultivated_area_vs_production.png
    ├── maximum_temperature_by_growth_stage.png
    ├── production_by_soil_type.png
    └── feature_correlation_heatmap.png
```

## 🚀 Run the Project

1. Download and extract this project folder.
2. Open a terminal in the project folder.
3. Install the required libraries:

   ```bash
   pip install -r requirements.txt
   ```

4. Start Jupyter Notebook:

   ```bash
   jupyter notebook
   ```

5. Open `Project_Notebook.ipynb` and run the cells in order.

## 👨‍💻 Author

**Harishraj R**  
GitHub: [HARISHRAJ-R-07](https://github.com/HARISHRAJ-R-07)

---

*Created for a Data Science mini-project submission.*
